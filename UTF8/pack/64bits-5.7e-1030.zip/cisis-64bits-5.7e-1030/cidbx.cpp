#define CISIS_DBX_INIT

#include <cidbx.c>
