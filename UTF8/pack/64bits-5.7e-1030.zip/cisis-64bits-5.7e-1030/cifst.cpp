
#define CIFST_SOURCE

#include <cifst.c>
