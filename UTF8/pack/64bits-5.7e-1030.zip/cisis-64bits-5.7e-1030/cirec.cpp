
#include <cirec.c>

#if MFUPDATE
#include <ciupd.c>
#endif

#if RECGIZM || RECXPND || RECDECO
#include <cigiz.c>
#endif
