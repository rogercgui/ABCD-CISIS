#define CISIS_TRM_INIT

#include <citrm.c>
