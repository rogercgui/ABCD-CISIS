/* ---------------------------------------------------------------- HLFILL.H */

/* -------------------------------------------------------------- prototypes */
char *hl_put(char *origb,char *key,char *pfx,char *sfx,char *copyb);

